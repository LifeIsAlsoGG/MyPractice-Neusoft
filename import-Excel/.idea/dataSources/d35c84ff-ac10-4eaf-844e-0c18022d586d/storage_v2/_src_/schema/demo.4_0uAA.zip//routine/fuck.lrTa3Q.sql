create
    definer = root@localhost procedure fuck(IN x int)
begin
select property into x from demo;
select x;
end;

